<?php

namespace App\Http\Controllers;

use App\Models\Subject;
use Illuminate\Http\Request;

class SubjectController extends Controller
{
    // Mostrar la lista de materias
    public function index()
    {
        $subjects = Subject::all(); // Obtener todas las materias
        return view('subjects.index', compact('subjects'));
    }

    // Mostrar el formulario para crear una nueva materia
    public function create()
    {
        return view('subjects.create');
    }

    // Almacenar una nueva materia
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
        ]);

        Subject::create($request->all());

        return redirect()->route('subjects.index')
                         ->with('success', 'Materia creada con éxito.');
    }

    // Mostrar los detalles de una materia
    public function show($id)
    {
        $subject = Subject::findOrFail($id); // Buscar la materia por su ID
        return view('subjects.show', compact('subject')); // Cargar la vista de detalles
    }

    // Mostrar el formulario para editar una materia
    public function edit($id)
    {
        $subject = Subject::findOrFail($id); // Buscar la materia por su ID
        return view('subjects.edit', compact('subject')); // Cargar la vista de edición
    }

    // Actualizar una materia existente
    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
        ]);

        $subject = Subject::findOrFail($id); // Buscar la materia por su ID
        $subject->update($request->all()); // Actualizar la materia

        return redirect()->route('subjects.index')
                         ->with('success', 'Materia actualizada con éxito.');
    }

    // Eliminar una materia
    public function destroy($id)
    {
        $subject = Subject::findOrFail($id); // Buscar la materia por su ID
        $subject->delete(); // Eliminar la materia

        return redirect()->route('subjects.index')
                         ->with('success', 'Materia eliminada con éxito.');
    }
}
