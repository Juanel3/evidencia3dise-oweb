<?php

namespace App\Http\Controllers;

use App\Models\Activity;
use App\Models\Subject;
use Illuminate\Http\Request;

class ActivityController extends Controller
{
    public function index(Subject $subject)
    {
        $activities = $subject->activities; // Obtener actividades asociadas a la materia
        return view('subjects.activities.index', compact('subject', 'activities'));
    }

    public function create(Subject $subject)
    {
        return view('subjects.activities.create', compact('subject'));
    }

    public function store(Request $request, Subject $subject)
    {
        $request->validate([
            'type' => 'required|string|max:255',
            'grade' => 'required|numeric',
            'date' => 'required|date',
        ]);

        $subject->activities()->create($request->all());

        return redirect()->route('subjects.activities.index', $subject)
                         ->with('success', 'Actividad creada con éxito.');
    }

    // Agrega otros métodos según sea necesario...
}
