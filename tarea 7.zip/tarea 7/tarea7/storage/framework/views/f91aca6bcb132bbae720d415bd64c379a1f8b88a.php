<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Materias</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Lista de Materias</h1>
        <a href="<?php echo e(route('subjects.create')); ?>" class="btn btn-primary mb-3">Agregar Nueva Materia</a>

        <?php if($subjects->isEmpty()): ?>
            <div class="alert alert-warning" role="alert">
                No hay materias registradas.
            </div>
        <?php else: ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($subject->id); ?></td>
                            <td><?php echo e($subject->name); ?></td>
                            <td>
                                <a href="<?php echo e(route('subjects.activities.index', $subject)); ?>" class="btn btn-info btn-sm">Ver Actividades</a>
                                <a href="<?php echo e(route('subjects.edit', $subject)); ?>" class="btn btn-warning btn-sm">Editar</a>
                                <form action="<?php echo e(route('subjects.destroy', $subject)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</body>
</html>
<?php /**PATH /Users/juanmiguelflores/Documents/Tecmilenio/Profesional/6 semestre/Diseño web/tarea 7/tarea7/resources/views/subjects/index.blade.php ENDPATH**/ ?>