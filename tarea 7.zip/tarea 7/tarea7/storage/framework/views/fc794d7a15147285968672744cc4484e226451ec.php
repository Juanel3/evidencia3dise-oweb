<!-- resources/views/subjects/activities/create.blade.php -->

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Actividad - <?php echo e($subject->name); ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h1>Agregar Actividad para <?php echo e($subject->name); ?></h1>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('subjects.activities.store', $subject->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="type">Tipo de Actividad</label>
                <input type="text" class="form-control" name="type" id="type" required>
            </div>
            <div class="form-group">
                <label for="grade">Calificación</label>
                <input type="number" class="form-control" name="grade" id="grade" required>
            </div>
            <div class="form-group">
                <label for="date">Fecha</label>
                <input type="date" class="form-control" name="date" id="date" required>
            </div>
            <button type="submit" class="btn btn-primary">Crear Actividad</button>
            <a href="<?php echo e(route('subjects.activities.index', $subject->id)); ?>" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</body>
</html>

<?php /**PATH /Users/juanmiguelflores/Documents/Tecmilenio/Profesional/6 semestre/Diseño web/tarea 7/tarea7/resources/views/subjects/activities/create.blade.php ENDPATH**/ ?>