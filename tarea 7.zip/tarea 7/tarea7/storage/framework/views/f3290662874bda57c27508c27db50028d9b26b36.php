<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Actividades</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Actividades de la Materia: <?php echo e($subject->name); ?></h1>
        <a href="<?php echo e(route('subjects.activities.create', $subject)); ?>" class="btn btn-primary mb-3">Agregar Nueva Actividad</a>

        <?php if($activities->isEmpty()): ?>
            <div class="alert alert-warning" role="alert">
                No hay actividades registradas para esta materia.
            </div>
        <?php else: ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tipo de Actividad</th>
                        <th>Calificación</th>
                        <th>Fecha</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($activity->id); ?></td>
                            <td><?php echo e($activity->type); ?></td>
                            <td><?php echo e($activity->grade); ?></td>
                            <td><?php echo e($activity->date); ?></td>
                            <td>
                                <a href="<?php echo e(route('subjects.activities.edit', [$subject, $activity])); ?>" class="btn btn-warning btn-sm">Editar</a>
                                <form action="<?php echo e(route('subjects.activities.destroy', [$subject, $activity])); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</body>
</html>
<?php /**PATH /Users/juanmiguelflores/Documents/Tecmilenio/Profesional/6 semestre/Diseño web/tarea 7/tarea7/resources/views/subjects/activities/index.blade.php ENDPATH**/ ?>