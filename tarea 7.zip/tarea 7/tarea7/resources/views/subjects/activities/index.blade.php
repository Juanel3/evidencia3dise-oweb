<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Actividades</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Actividades de la Materia: {{ $subject->name }}</h1>
        <a href="{{ route('subjects.activities.create', $subject) }}" class="btn btn-primary mb-3">Agregar Nueva Actividad</a>

        @if ($activities->isEmpty())
            <div class="alert alert-warning" role="alert">
                No hay actividades registradas para esta materia.
            </div>
        @else
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tipo de Actividad</th>
                        <th>Calificación</th>
                        <th>Fecha</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($activities as $activity)
                        <tr>
                            <td>{{ $activity->id }}</td>
                            <td>{{ $activity->type }}</td>
                            <td>{{ $activity->grade }}</td>
                            <td>{{ $activity->date }}</td>
                            <td>
                                <a href="{{ route('subjects.activities.edit', [$subject, $activity]) }}" class="btn btn-warning btn-sm">Editar</a>
                                <form action="{{ route('subjects.activities.destroy', [$subject, $activity]) }}" method="POST" style="display:inline;">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        @endif
    </div>
</body>
</html>
