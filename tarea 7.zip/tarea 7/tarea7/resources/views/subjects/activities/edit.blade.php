<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Actividad - {{ $subject->name }}</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Editar Actividad de {{ $subject->name }}</h1>

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('subjects.activities.update', [$subject, $activity]) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="type">Tipo de Actividad</label>
                <input type="text" name="type" class="form-control" id="type" value="{{ $activity->type }}" required>
            </div>
            <div class="form-group">
                <label for="grade">Calificación</label>
                <input type="number" name="grade" class="form-control" id="grade" value="{{ $activity->grade }}" required min="0" max="100" step="0.01">
            </div>
            <div class="form-group">
                <label for="date">Fecha</label>
                <input type="date" name="date" class="form-control" id="date" value="{{ $activity->date }}" required>
            </div>
            <button type="submit" class="btn btn-primary">Actualizar Actividad</button>
            <a href="{{ route('subjects.activities.index', $subject) }}" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</body>
</html>
