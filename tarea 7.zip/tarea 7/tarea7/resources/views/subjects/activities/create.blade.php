<!-- resources/views/subjects/activities/create.blade.php -->

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Actividad - {{ $subject->name }}</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h1>Agregar Actividad para {{ $subject->name }}</h1>

        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('subjects.activities.store', $subject->id) }}" method="POST">
            @csrf
            <div class="form-group">
                <label for="type">Tipo de Actividad</label>
                <input type="text" class="form-control" name="type" id="type" required>
            </div>
            <div class="form-group">
                <label for="grade">Calificación</label>
                <input type="number" class="form-control" name="grade" id="grade" required>
            </div>
            <div class="form-group">
                <label for="date">Fecha</label>
                <input type="date" class="form-control" name="date" id="date" required>
            </div>
            <button type="submit" class="btn btn-primary">Crear Actividad</button>
            <a href="{{ route('subjects.activities.index', $subject->id) }}" class="btn btn-secondary">Cancelar</a>
        </form>
    </div>
</body>
</html>

