<!-- resources/views/subjects/show.blade.php -->

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalles de {{ $subject->name }}</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h1>Detalles de la Materia: {{ $subject->name }}</h1>
        
        <p><strong>ID:</strong> {{ $subject->id }}</p>
        <p><strong>Descripción:</strong> {{ $subject->description }}</p>

        <a href="{{ route('subjects.index') }}" class="btn btn-secondary">Volver a la lista</a>
    </div>
</body>
</html>
