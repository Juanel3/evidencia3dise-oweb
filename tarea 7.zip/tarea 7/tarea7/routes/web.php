<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SubjectController;
use App\Http\Controllers\ActivityController;

// Ruta para la página principal o dashboard (opcional)
Route::get('/', function () {
    return view('welcome'); // Asegúrate de que existe la vista welcome.blade.php
});

// Rutas para el CRUD de Materias
Route::resource('subjects', SubjectController::class);

// Rutas para el CRUD de Actividades asociadas a Materias
Route::resource('subjects.activities', ActivityController::class);
