<!-- resources/views/superheroes/index.blade.php -->


<?php $__env->startSection('content'); ?>
<h1>Lista de Superhéroes</h1>
<a href="<?php echo e(route('superheroes.create')); ?>">Registrar un nuevo superhéroe</a>

<table style="border-collapse: collapse; width: 100%;">
    <thead>
        <tr>
            <th style="border: 1px solid black; padding: 8px;">ID</th>
            <th style="border: 1px solid black; padding: 8px;">Nombre</th>
            <th style="border: 1px solid black; padding: 8px;">Alias</th>
            <th style="border: 1px solid black; padding: 8px;">Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $superheroes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $superheroe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="border: 1px solid black; padding: 8px;"><?php echo e($superheroe->id); ?></td>
            <td style="border: 1px solid black; padding: 8px;"><?php echo e($superheroe->real_name); ?></td>
            <td style="border: 1px solid black; padding: 8px;"><?php echo e($superheroe->hero_name); ?></td>
            <td style="border: 1px solid black; padding: 8px;">
                <a href="<?php echo e(route('superheroes.show', $superheroe->id)); ?>">Ver</a>
                <a href="<?php echo e(route('superheroes.edit', $superheroe->id)); ?>">Editar</a>
                <form action="<?php echo e(route('superheroes.destroy', $superheroe->id)); ?>" method="POST" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit">Eliminar</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/juanmiguelflores/Documents/Tecmilenio/Profesional/6 semestre/Diseño web/actividad 8/actividad8/resources/views/superheroes/index.blade.php ENDPATH**/ ?>