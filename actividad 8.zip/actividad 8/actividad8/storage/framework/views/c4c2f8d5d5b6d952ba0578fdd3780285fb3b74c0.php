<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Superhéroes</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>"> <!-- Cambia esta línea según tu estructura -->
</head>
<body>
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html>
<?php /**PATH /Users/juanmiguelflores/Documents/Tecmilenio/Profesional/6 semestre/Diseño web/actividad 8/actividad8/resources/views/layout.blade.php ENDPATH**/ ?>