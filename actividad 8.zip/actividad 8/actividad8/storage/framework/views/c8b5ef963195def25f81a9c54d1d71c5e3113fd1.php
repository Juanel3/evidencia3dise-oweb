<!-- resources/views/superheroes/create.blade.php -->


<?php $__env->startSection('content'); ?>
<h1>Registrar Superhéroe</h1>
<form action="<?php echo e(route('superheroes.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <label>Nombre Real:</label>
    <input type="text" name="real_name" required><br>

    <label>Alias del Héroe:</label>
    <input type="text" name="hero_name" required><br>

    <label>Foto (URL):</label>
    <input type="text" name="photo_url" required><br>

    <label>Información Adicional:</label>
    <textarea name="additional_info"></textarea><br>

    <button type="submit">Registrar</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/juanmiguelflores/Documents/Tecmilenio/Profesional/6 semestre/Diseño web/actividad 8/actividad8/resources/views/superheroes/create.blade.php ENDPATH**/ ?>