<?php

// app/Http/Controllers/SuperheroController.php

namespace App\Http\Controllers;

use App\Models\Superhero;
use Illuminate\Http\Request;

class SuperheroController extends Controller
{
    public function index() {
        $superheroes = Superhero::all();
        return view('superheroes.index', compact('superheroes'));
    }

    public function create() {
        return view('superheroes.create');
    }

    public function show($id) {
        $superheroe = Superhero::findOrFail($id);
        return view('superheroes.show', compact('superheroe'));
    }

    public function edit($id) {
        $superheroe = Superhero::findOrFail($id);
        return view('superheroes.edit', compact('superheroe'));
    }
}
