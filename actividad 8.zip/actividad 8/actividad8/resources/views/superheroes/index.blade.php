<!-- resources/views/superheroes/index.blade.php -->
@extends('layout')

@section('content')
<h1>Lista de Superhéroes</h1>
<a href="{{ route('superheroes.create') }}">Registrar un nuevo superhéroe</a>

<table style="border-collapse: collapse; width: 100%;">
    <thead>
        <tr>
            <th style="border: 1px solid black; padding: 8px;">ID</th>
            <th style="border: 1px solid black; padding: 8px;">Nombre</th>
            <th style="border: 1px solid black; padding: 8px;">Alias</th>
            <th style="border: 1px solid black; padding: 8px;">Acciones</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($superheroes as $superheroe)
        <tr>
            <td style="border: 1px solid black; padding: 8px;">{{ $superheroe->id }}</td>
            <td style="border: 1px solid black; padding: 8px;">{{ $superheroe->real_name }}</td>
            <td style="border: 1px solid black; padding: 8px;">{{ $superheroe->hero_name }}</td>
            <td style="border: 1px solid black; padding: 8px;">
                <a href="{{ route('superheroes.show', $superheroe->id) }}">Ver</a>
                <a href="{{ route('superheroes.edit', $superheroe->id) }}">Editar</a>
                <form action="{{ route('superheroes.destroy', $superheroe->id) }}" method="POST" style="display:inline;">
                    @csrf
                    @method('DELETE')
                    <button type="submit">Eliminar</button>
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@endsection
