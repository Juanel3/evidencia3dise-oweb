<!-- resources/views/superheroes/edit.blade.php -->
@extends('layout')

@section('content')
<h1>Editar Superhéroe</h1>
<form action="{{ route('superheroes.update', $superheroe->id) }}" method="POST">
    @csrf
    @method('PUT')

    <label>Nombre Real:</label>
    <input type="text" name="real_name" value="{{ $superheroe->real_name }}" required><br>

    <label>Alias del Héroe:</label>
    <input type="text" name="hero_name" value="{{ $superheroe->hero_name }}" required><br>

    <label>Foto (URL):</label>
    <input type="text" name="photo_url" value="{{ $superheroe->photo_url }}" required><br>

    <label>Información Adicional:</label>
    <textarea name="additional_info">{{ $superheroe->additional_info }}</textarea><br>

    <button type="submit">Actualizar</button>
</form>
@endsection
