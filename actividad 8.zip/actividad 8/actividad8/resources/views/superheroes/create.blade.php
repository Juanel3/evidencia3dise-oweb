<!-- resources/views/superheroes/create.blade.php -->
@extends('layout')

@section('content')
<h1>Registrar Superhéroe</h1>
<form action="{{ route('superheroes.store') }}" method="POST">
    @csrf
    <label>Nombre Real:</label>
    <input type="text" name="real_name" required><br>

    <label>Alias del Héroe:</label>
    <input type="text" name="hero_name" required><br>

    <label>Foto (URL):</label>
    <input type="text" name="photo_url" required><br>

    <label>Información Adicional:</label>
    <textarea name="additional_info"></textarea><br>

    <button type="submit">Registrar</button>
</form>
@endsection
