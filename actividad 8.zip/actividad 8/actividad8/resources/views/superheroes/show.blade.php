<!-- resources/views/superheroes/show.blade.php -->
@extends('layout')

@section('content')
<h1>Detalles de {{ $superheroe->hero_name }}</h1>
<p><strong>Nombre Real:</strong> {{ $superheroe->real_name }}</p>
<p><strong>Alias:</strong> {{ $superheroe->hero_name }}</p>
<p><strong>Foto:</strong> <img src="{{ $superheroe->photo_url }}" alt="Foto"></p>
<p><strong>Información Adicional:</strong> {{ $superheroe->additional_info }}</p>
<a href="{{ route('superheroes.index') }}">Volver a la lista</a>
@endsection
